"""Builds preview/ — self-contained copies of every page (CSS + JS inlined).
Use these for any viewer that opens a single HTML file without its neighbours.
Run from the project root:  python3 tools/build_preview.py"""
import pathlib, re
root = pathlib.Path(__file__).resolve().parent.parent
out = root / "preview"; out.mkdir(exist_ok=True)
css = (root / "css/style.css").read_text()
js = (root / "js/main.js").read_text()
for page in sorted(root.glob("*.html")):
    h = page.read_text()
    h = h.replace('<link rel="stylesheet" href="css/style.css">', f"<style>\n{css}\n</style>")
    h = re.sub(r'<script src="js/main.js" defer></script>', lambda m: f"<script>\n{js}\n</script>", h)
    h = h.replace('href="assets/', 'href="../assets/').replace('src="assets/', 'src="../assets/')
    (out / page.name).write_text(h)
    print("built", out / page.name)
