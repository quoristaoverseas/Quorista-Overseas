/* Quorista Overseas — site behaviour (shared by every page) */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];

  /* ---------- footer year ---------- */
  const y = $('#year'); if (y) y.textContent = new Date().getFullYear();

  /* ---------- scroll progress + sticky header ---------- */
  const bar = $('#progressBar'), header = $('.site-header');
  const onScroll = () => {
    const h = document.documentElement;
    if (bar) bar.style.width = (h.scrollTop / (h.scrollHeight - h.clientHeight || 1)) * 100 + '%';
    if (header) header.classList.toggle('scrolled', h.scrollTop > 30);
  };
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* ---------- mobile menu ---------- */
  const toggle = $('.menu-toggle'), nav = $('.nav');
  if (toggle && nav) {
    const setOpen = open => { nav.classList.toggle('open', open); toggle.setAttribute('aria-expanded', String(open)); };
    toggle.addEventListener('click', () => setOpen(!nav.classList.contains('open')));
    $$('a', nav).forEach(a => a.addEventListener('click', () => setOpen(false)));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') setOpen(false); });
  }

  /* ---------- reveal on scroll (always ends up visible, even in static previews) ---------- */
  const items = $$('.reveal');
  const show = el => el.classList.add('in');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(es => es.forEach(e => {
      if (e.isIntersecting) { show(e.target); io.unobserve(e.target); }
    }), { threshold: 0.08, rootMargin: '0px 0px 12% 0px' });
    items.forEach(i => io.observe(i));
    // safety net: anything still hidden shortly after load is revealed
    window.addEventListener('load', () => setTimeout(() => items.forEach(show), 2200));
  } else items.forEach(show);

  /* ---------- missing image / logo fallbacks ---------- */
  const wordmark = () => {
    const s = document.createElement('span');
    s.className = 'wordmark'; s.innerHTML = 'Quorista <b>Overseas</b>';
    return s;
  };
  const handleBroken = img => {
    if (img.closest('.brand, .footer-top')) {
      if (img.alt && /logo|quorista/i.test(img.alt) && !img.dataset.done) {
        img.dataset.done = '1'; img.replaceWith(wordmark());
      }
      return;
    }
    if (img.id === 'modalImage') return;
    const host = img.parentElement;
    if (host) host.classList.add('img-missing');
  };
  const checkImg = img => {
    if (img.complete && img.naturalWidth === 0 && img.getAttribute('src')) handleBroken(img);
  };
  $$('img').forEach(img => {
    img.addEventListener('error', () => handleBroken(img));
    checkImg(img);
  });

  /* ---------- destination filter ---------- */
  const cards = $$('.dest-card'), note = $('.atlas-note');
  $$('.filter').forEach(btn => btn.addEventListener('click', () => {
    $$('.filter').forEach(b => b.classList.remove('active')); btn.classList.add('active');
    const f = btn.dataset.filter; let n = 0;
    cards.forEach(c => {
      const ok = f === 'all' || c.dataset.region === f;
      c.classList.toggle('hide', !ok);
      if (ok) { n++; show(c); }
    });
    if (note) note.textContent = n + ' / ' + cards.length + ' destinations';
  }));

  /* ---------- destination modal ---------- */
  const modal = $('#destModal');
  if (modal) {
    const mImg = $('#modalImage');
    const close = () => { modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true'); };
    cards.forEach(c => {
      c.tabIndex = 0; c.setAttribute('role', 'button');
      const open = () => {
        const img = $('img', c);
        mImg.src = img.src; mImg.alt = img.alt;
        mImg.parentElement.classList.toggle('img-missing', c.classList.contains('img-missing'));
        $('#modalIndex').textContent = c.dataset.index;
        $('#modalRegion').textContent = $('.country-region', c).textContent;
        $('#modalTitle').textContent = c.dataset.country;
        $('#modalCopy').textContent = c.dataset.copy;
        $('#modalTags').innerHTML = c.dataset.tags.split('|').map(t => '<span>' + t + '</span>').join('');
        modal.classList.add('open'); modal.setAttribute('aria-hidden', 'false');
      };
      c.addEventListener('click', open);
      c.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    });
    $$('[data-close-modal]', modal).forEach(el => el.addEventListener('click', close));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') close(); });
  }

  /* ---------- careers tabs ---------- */
  const tabs = $$('.career-tab'), panels = $$('.career-panel');
  if (tabs.length) {
    const ids = tabs.map(t => t.dataset.tab);
    const showTab = id => {
      tabs.forEach(t => { const on = t.dataset.tab === id; t.classList.toggle('active', on); t.setAttribute('aria-selected', String(on)); });
      panels.forEach(p => p.classList.toggle('active', p.id === id));
    };
    tabs.forEach(t => t.addEventListener('click', () => { showTab(t.dataset.tab); history.replaceState(null, '', '#' + t.dataset.tab); }));
    const fromHash = () => { const h = location.hash.slice(1); showTab(ids.includes(h) ? h : ids[0]); };
    window.addEventListener('hashchange', fromHash); fromHash();
  }

  /* ---------- forms (enquiry + careers) ---------- */
  $$('form.ajax-form').forEach(form => {
    const status = $('.form-status', form), btn = $('button[type=submit]', form);
    const u = $('[name=_url]', form); if (u) u.value = location.href;
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const em = $('[type=email]', form), rt = $('[name=_replyto]', form);
      if (em && rt) rt.value = em.value;
      btn.disabled = true; status.className = 'form-status'; status.textContent = 'Sending…';
      try {
        const res = await fetch(form.action, { method: 'POST', headers: { Accept: 'application/json' }, body: new FormData(form) });
        if (!res.ok) throw new Error('bad status');
        form.reset(); status.classList.add('ok');
        status.textContent = 'Thank you! We have received your submission and will get back to you soon.';
      } catch (err) {
        status.classList.add('err');
        status.textContent = 'Something went wrong. Please try again or message us on WhatsApp.';
      } finally { btn.disabled = false; }
    });
  });
})();
