# Quorista Overseas website

```
quorista-site/
├── index.html        Home (hero, destinations atlas, pathways, universities, scholarships, services, enquiry form)
├── about.html        About us
├── careers.html      Careers: full-time / part-time / unpaid internship tabs, one form each
├── privacy.html      Privacy Policy   (draft: have it legally reviewed)
├── terms.html        Terms & Conditions (draft: have it legally reviewed)
├── css/style.css     All styling; brand colours are the variables in :root
├── js/main.js        Menu, scroll effects, destination filter + modal, careers tabs, forms
├── assets/
│   ├── quorista-logo.png
│   ├── favicon.png
│   ├── university-wall.jpg
│   ├── destinations/ uae.jpg china.jpg south-korea.jpg singapore.jpg malaysia.jpg thailand.jpg
│   │                 hungary.jpg taiwan.jpg vietnam.jpg slovakia.jpg slovenia.jpg germany.jpg
│   │                 france.jpg russia.jpg
│   └── editorial/    students.jpg airplane.jpg campus.jpg
├── tools/build_preview.py   Makes preview/ (single-file pages with CSS+JS inlined)
└── preview/                 Generated; open these if your viewer can't follow relative links
```

Copy your existing `assets/` folder in as-is: file names are unchanged.
If a photo or the logo is missing, the page shows a gradient / text wordmark instead of a broken image.

Forms post to formsubmit.co → quoristaoverseas@gmail.com (confirm the address once on the first submission).
